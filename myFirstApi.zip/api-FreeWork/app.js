import express from 'express';
import morgan from 'morgan';
import cors from 'cors';
import freelancersController from './controllers/FreelancersController.js';
import empresasController from './controllers/empresaController.js';

const app = express();

const OptCors = {origin:'*',
        optionsSuccessStatus:204
};

app.use(cors(OptCors));

app.use(morgan('dev'));
app.use(express.static("public"));
app.use(express.json());


app.use((req, res, next) => {
    console.log('Se recibió una solicitud');
    next();
  });

app.use('/api/freelancers', freelancersController);

app.use('/api/empresas', empresasController);

app.use((err,  res, next) => {
  console.error(err.stack);
  res.status(500).send("Error Del Servidor");
  next();
});


const PORT = 3001;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en el puerto ${PORT}` + ' http://localhost:3001');
});
