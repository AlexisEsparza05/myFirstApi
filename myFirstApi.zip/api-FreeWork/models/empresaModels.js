class Empresa {
    constructor(id, nombre_empresa, correo_electronico, telefono, representante) {
        this.id = id;
        this.nombre_empresa = nombre_empresa;
        this.correo_electronico = correo_electronico;
        this.telefono = telefono;
        this.representante = representante;
    }
}

export default Empresa;
